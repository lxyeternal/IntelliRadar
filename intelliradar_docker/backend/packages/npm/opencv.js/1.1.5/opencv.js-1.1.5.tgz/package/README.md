#### OpenCV.js

OpenCV.js is asm.js/WASM implementation of OpenCV. This project is made possible by support of Intel corporation and Google through Google Summer of Code program. This library is currently generated based on OpenCV version 3.3.

#### Installation

```
npm install opencv.js
```

#### Supported OpenCV Subset
Currently, select functions (more than 100) form the following OpenCV modules are exported.

* Core
* Image processing
* Video
* Object detection
* Image codecs


#### How to Use
```js
cv = require('opencv.js');
```

#### Demos
Use this [pointer](https://huningxin.github.io/opencv.js/samples/index.html) to access the demos.

#### API
Please refer to  the [OpenCV documentation](https://huningxin.github.io/opencv_docs/tutorial_js_table_of_contents_core.html).

#### Basic Types
```cv.Mat``` is the main data structure that is used by the functions. The following constructors are available to create matrices.

```
cv.Mat()
cv.Mat(another_mat)
cv.Mat(size, type)
cv.Mat(rows, cols, type, data, step)
```

Simple types such as ```cv::Rect```, ```cv::Point``` are represented using JavaScript value objects.

#### Examples
##### Working with images
##### Working with videos
##### Canny Edge Detection
##### Gaussian Image Pyramids



#### Contributers
* Sajjad Taheri
* Congxiang Pan
* Ningxin Hu
* Wenyao Gan
* Gang Song

## License
The BSD-3-Cluase
