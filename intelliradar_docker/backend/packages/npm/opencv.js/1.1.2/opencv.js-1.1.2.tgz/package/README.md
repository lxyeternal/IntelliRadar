## OpenCV.js

OpenCV.js is asm.js/WASM implementation of OpenCV. This project is made possible by support of Intel corporation and Google through Google Summer of Code program.

## Installation

```
npm install opencv.js
```

## Supported OpenCV Subset
Currently, select functions form the following OpenCV modules are exported. they are based on OpenCV 3.3.

    1. Core
    2. Image processing
    3. Video
    4. Object detection
    6. Image codecs

## How to Use
```js
cv = require('opencv.js');
var mat = new cv.Mat();
```

## Testing
```sh
node tests
```

## API


## Contributers
* Sajjad Taheri
* Congxiang Pan
* Ningxin Hu
* Wenyao Gan
* Gang Song

## License
The BSD-3-Cluase
