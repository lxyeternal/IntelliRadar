This package is no longer dangerous.
