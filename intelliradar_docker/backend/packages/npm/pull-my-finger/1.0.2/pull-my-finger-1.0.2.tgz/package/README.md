# pull-my-finger

Make a fart sound on installation.
